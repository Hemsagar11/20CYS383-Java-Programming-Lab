package com.amrita.jpl.cys21016.endsem;

import javax.swing.*;
import java.util.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;


/**
 * Endsem evaluation JAVA PROGRAMMING LAB -20CYS383
 * created  a file managing system.
 * @author G H Hem Sagar
 * @version 1.0
 * */
abstract class File {
    private String fileName;
    private long fileSize;

    public File(String fileName, long fileSize) {
        this.fileName = fileName;
        this.fileSize = fileSize;
    }

    public String getFileName() {
        return fileName;
    }

    public long getFileSize() {
        return fileSize;
    }
    public void displayFileDetails(){

    }
}


class Document extends File{
    private String documentType;

    public Document(String fileName, long fileSize, String documentType) {
        super(fileName, fileSize);
        this.documentType = documentType;
    }
    public String getDocumentType(){
        return documentType;
    }
}
class Image extends File{
    private String resolution;
    public Image(String fileName, long fileSize, String resolution){
        super(fileName,fileSize);
        this.resolution = resolution;
    }
    public String getResolution(){
        return resolution;
    }


}

class Video extends File{
    private String duration;
    public Video(String fileName,long fileSize,String duration){
        super(fileName,fileSize);
        this.duration = duration;
    }

    public String getDuration(){
        return duration;
    }


}
interface FileManager {
    void addFile(File file);
    void deleteFile(String fileName);
    void saveToFile();
    void loadFromFile();
    ArrayList<File> getFiles();
}

class FileManagerImpl implements FileManager{
    ArrayList<File> files;

    public FileManagerImpl(){
        files = new ArrayList<>();
    }

    @Override
    public void addFile(File file) {
        files.add(file);
    }

    @Override
    public void deleteFile(String fileName) {
        for (File file : files){
            if(file.getFileName().equals(fileName)){
                files.remove(file);
            }
        }
    }

    @Override
    public void saveToFile() {
        try (PrintWriter writer = new PrintWriter("filedetails.txt")) {
            for (File file : files) {
                writer.println(file.getClass().getSimpleName());
                writer.println(file.getFileName());
                writer.println(file.getFileSize());
                if (file instanceof Document) {
                    writer.println(((Document) file).getDocumentType());
                } else if (file instanceof Image) {
                    writer.println(((Image) file).getResolution());
                } else if (file instanceof Video) {
                    writer.println(((Video) file).getDuration());
                }
            }
        } catch (FileNotFoundException e) {
            JOptionPane.showMessageDialog(null, "Error saving file.", "Error", JOptionPane.ERROR_MESSAGE);
        }

    }

    @Override
    public void loadFromFile() {
        try (BufferedReader reader = new BufferedReader(new FileReader("filedetails.txt"))) {
            files.clear();
            String line;
            while ((line = reader.readLine()) != null) {
                String type = line.trim();
                String name = reader.readLine().trim();
                int size = Integer.parseInt(reader.readLine().trim());
                if (type.equals("Document")) {
                    String documentType = reader.readLine().trim();
                    addFile(new Document(name, size, documentType));
                } else if (type.equals("Image")) {
                    String resolution = reader.readLine().trim();
                    addFile(new Image(name, size, resolution));
                } else if (type.equals("Video")) {
                    String duration = (reader.readLine().trim());
                    addFile(new Video(name, size, duration));
                }
            }

        } catch (IOException e) {
            System.out.println("File not Read.");
        }
    }

    @Override
    public ArrayList<File> getFiles() {
        return files;
    }
}
public class FileManagementSystemUI {
    FileManager fileManager;
    private DefaultTableModel tableModel;
    public void FileManagementSystemUI(){
        fileManager = new FileManagerImpl();
        tableModel = new DefaultTableModel();
        tableModel.addColumn("File Name");
        tableModel.addColumn("File Size");
        tableModel.addColumn("File Type");
    }

    public void GUI(){
        JFrame frame = new JFrame("21UCYS End Semester Assignment File Manager");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 400);
        frame.setLayout(new BorderLayout());

        JPanel inputPanel = new JPanel(new GridLayout(1,6));
        JLabel fileName = new JLabel("File Name: ");
        JTextField nameinput = new JTextField();
        JLabel fileSize = new JLabel("File Size: ");
        JTextField sizeinput = new JTextField();
        JLabel fileType = new JLabel("File Type: ");
        String[] items = {"Document", "Image", "Video"};
        JComboBox<String> dropdown = new JComboBox<>(items);
        dropdown.setBounds(50, 50, 150, 30);
        inputPanel.add(fileName);
        inputPanel.add(nameinput);
        inputPanel.add(fileSize);
        inputPanel.add(sizeinput);
        inputPanel.add(fileType);
        inputPanel.add(dropdown);
        frame.add(inputPanel,BorderLayout.NORTH);

        JPanel displaypanel = new JPanel(new BorderLayout());
        JTable fileTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(fileTable);
        displaypanel.add(scrollPane, BorderLayout.CENTER);
        frame.add(displaypanel,BorderLayout.CENTER);

        JButton addButton = new JButton("Add File");
        JButton deleteButton = new JButton("Delete File");
        JButton refreshButton = new JButton("Refresh");

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(addButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(refreshButton);

        frame.add(buttonPanel, BorderLayout.SOUTH);

        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            }
        });

        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = fileTable.getSelectedRow();
                if (selectedRow != -1) {
                    String fileName = (String) tableModel.getValueAt(selectedRow, 0);
                    fileManager.deleteFile(fileName);
                    tableModel.removeRow(selectedRow);
                }
            }
        });
        frame.setVisible(true);
    }


    private void showAddDocumentDialog(JFrame parentFrame, String fileName, int fileSize) {
        JPanel panel = new JPanel(new GridLayout(1, 2));
        JTextField documentTypeField = new JTextField();
        panel.add(new JLabel("Document Type:"));
        panel.add(documentTypeField);

        int result = JOptionPane.showConfirmDialog(parentFrame, panel, "Add Document", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            String documentType = documentTypeField.getText();
            Document document = new Document(fileName, fileSize, documentType);
            fileManager.addFile(document);
            tableModel.addRow(new Object[]{document.getFileName(), document.getFileSize(), document.getDocumentType()});
        }
    }

    private void showAddImageDialog(JFrame parentFrame, String fileName, int fileSize) {
        JPanel panel = new JPanel(new GridLayout(1, 2));
        JTextField resolutionField = new JTextField();
        panel.add(new JLabel("Resolution:"));
        panel.add(resolutionField);

        int result = JOptionPane.showConfirmDialog(parentFrame, panel, "Add Image", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            String resolution = resolutionField.getText();
            Image image = new Image(fileName, fileSize, resolution);
            fileManager.addFile(image);
            tableModel.addRow(new Object[]{image.getFileName(), image.getFileSize(), image.getResolution()});
        }
    }

    private void showAddVideoDialog(JFrame parentFrame, String fileName, int fileSize) {
        JPanel panel = new JPanel(new GridLayout(1, 2));
        JTextField durationField = new JTextField();
        panel.add(new JLabel("Duration (seconds):"));
        panel.add(durationField);

        int result = JOptionPane.showConfirmDialog(parentFrame, panel, "Add Video", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            String duration = durationField.getText();
            Video video = new Video(fileName, fileSize, duration);
            fileManager.addFile(video);
            tableModel.addRow(new Object[]{video.getFileName(), video.getFileSize(), video.getDuration() + " seconds"});
        }
    }

    private void updateTableModel() {
        tableModel.setRowCount(0);
        for (File file : ((FileManagerImpl) fileManager).getFiles()) {
            if (file instanceof Document) {
                tableModel.addRow(new Object[]{file.getFileName(), file.getFileSize(), ((Document) file).getDocumentType()});
            } else if (file instanceof Image) {
                tableModel.addRow(new Object[]{file.getFileName(), file.getFileSize(),"Image"});
            } else if (file instanceof Video) {
                tableModel.addRow(new Object[]{file.getFileName(), file.getFileSize(), "Video"});
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                FileManagementSystemUI systemUI = new FileManagementSystemUI();
                systemUI.GUI();
            }
        });
    }
}
