package com.amrita.jpl.cys21016.pract.net;
import java.io.*;
import java.net.*;
import java.nio.file.Files;

abstract class FileTransfer{
    void sendFile(String filename) {
        File file = new File(filename);
        byte[] fileData = new byte[(int) file.length()];
        try (InputStream inputStream = new FileInputStream(file)) {
            inputStream.read(fileData);
            saveFile(fileData, filename);
        } catch (IOException e) {
            System.out.println("Error in reading the file -> " + e.getMessage());
        }
    }
    abstract void saveFile(byte[] fileData,String filename);
}
interface FileTransferListener{
    void onFileSent(String Filename);
    void onFileSaved(String Filename);
}

class FileTransferClient extends FileTransfer implements FileTransferListener{
    Socket clientSocket;
    DataOutputStream outputStream;
    DataInputStream inputStream;
    public FileTransferClient(){
        try{
            clientSocket = new Socket("localhost",21016);
            DataOutputStream outputStream = new DataOutputStream(clientSocket.getOutputStream());
            DataInputStream inputStream = new DataInputStream(clientSocket.getInputStream());
        }catch(IOException e){
            System.out.println("Client Socket can not be established.");
            e.printStackTrace();
        }
    }
    @Override
    void sendFile(String filename) {
        super.sendFile(filename);
    }

    @Override
    void saveFile(byte[] fileData, String filename) {
        try {
            //outputStream.writeUTF(filename);
            outputStream.write(fileData,0, fileData.length);
        } catch (IOException e) {
            System.out.println("Error sending file: " + e.getMessage());
        }
    }

    @Override
    public void onFileSent(String filename) {
        System.out.println("The file "+filename+"is sent.");
    }

    @Override
    public void onFileSaved(String Filename) {
        //Not used in the client side.
    }
};
class FileTransferServer extends FileTransfer implements FileTransferListener{
    ServerSocket serverSocket;
    Socket clientSocket;
    DataInputStream inputStream;
    DataOutputStream outputStream;
    public void FileTransferServer(){
        start();
    }
    void start(){
        try{
            serverSocket = new ServerSocket(21016);
            clientSocket = serverSocket.accept();
            System.out.println("Server started on port : "+serverSocket.getLocalPort());
            inputStream = new DataInputStream(clientSocket.getInputStream());
            //outputStream = new DataOutputStream(clientSocket.getOutputStream());
            //String filename = inputStream.readUTF();
            byte[] readData = inputStream.readAllBytes();
            saveFile(readData,"/Users/hemsagar/Btech/sem-04/Java_programming/Programs/JAVA PROGRAMMING LAB/src/com/amrita/jpl/cys21016/pract/net/server.txt");
        }catch (IOException e ){
            System.out.println("Could not start the server. Please Restart it.");
            e.printStackTrace();
        }

    }
    @Override
    void saveFile(byte[] fileData, String filename) {
        try{
            File file = new File(filename);
            Files.write(file.toPath(),fileData);
            onFileSaved(filename);
            inputStream.close();
            clientSocket.close();
        }catch (IOException e){
                System.out.println("error Saving file.");
        }
    }
    @Override
    public void onFileSent(String filename) {
        System.out.println("The file "+filename+"is sent.");
    }

    @Override
    public void onFileSaved(String Filename) {
        System.out.println("The file "+Filename+"is saved.");
    }
};
public class simpleFileTransfer extends Thread{
    @Override
    public void run(){
        FileTransferClient client = new FileTransferClient();
        client.sendFile("/Users/hemsagar/Btech/sem-04/Java_programming/Programs/JAVA PROGRAMMING LAB/src/com/amrita/jpl/cys21016/pract/net/1.txt");
    }

    public static void main(String [] args){
        FileTransferServer server = new FileTransferServer();
        server.start();

        simpleFileTransfer thread1 = new simpleFileTransfer();
        thread1.start();

    }
}
